<?php
/**
 * Created by PhpStorm.
 * User: Brian Mutinda
 * Date: 30/06/2018
 * Time: 03:24 PM
 */
?>

<html>
    <head>
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    </head>

    <body>
        <div class="container">
            <div class="row">

                <div class="col-lg-8">

                    <h1>All users</h1>
                    <table class="table">

                        <tr class="success">
                            <th>User ID</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Password</th>
                            <th>Age</th>
                            <th>Gender</th>
                            <th>Weight</th>
                            <th>Target Weight</th>
                            <th>Preffered Location</th>
                            <th>Api Token</th>
                            <th>Delete Account</th>
                        </tr>

                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->id); ?></td>
                                <td><?php echo e($user->firstname); ?></td>
                                <td><?php echo e($user->lastname); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->password); ?></td>
                                <td><?php echo e($user->age); ?></td>
                                <td><?php echo e($user->gender); ?></td>
                                <td><?php echo e($user->weight); ?></td>
                                <td><?php echo e($user->target_weight); ?></td>
                                <td><?php echo e($user->preffered_location); ?></td>
                                <td><?php echo e($user->api_token); ?></td>
                                <td><a href="#">Delete</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </table>
                </div>
            </div>
        </div>
    </body>
</html>

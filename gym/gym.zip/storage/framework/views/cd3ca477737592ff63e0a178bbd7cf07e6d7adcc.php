<?php
/**
 * Created by PhpStorm.
 * User: Brian Mutinda
 * Date: 30/06/2018
 * Time: 03:31 PM
 */
?>

<html>
<head>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>

<body>
<div class="container">
    <div class="row">

        <div class="col-lg-2"></div>

        <div class="col-lg-8">
            <h1>All Instructors</h1>
            <!--Check for sucess message-->
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>

            <table class="table table-success">
                <tr class="success">
                    <th>Photo</th>
                    <th>Instructor Id</th>
                    <th>Gym Id</th>
                    <th>Gym Location</th>
                    <th>Name</th>
                    <th>Contacts</th>
                    <th>Email</th>
                    <th>Gender</th>
                    <th>Delete</th>
                </tr>

                <?php $__currentLoopData = $instructor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><img src="/images/<?php echo e($instructor->photo); ?>" style="height: 50px; width: 50px;"></td>
                        <td><?php echo e($instructor->id); ?></td>
                        <td><?php echo e($instructor->gym_id); ?></td>
                        <td><?php echo e($instructor->gym_name); ?></td>
                        <td><?php echo e($instructor->name); ?></td>
                        <td><?php echo e($instructor->contacts); ?></td>
                        <td><?php echo e($instructor->email); ?></td>
                        <td><?php echo e($instructor->gender); ?></td>
                        <td><a href="/instructor/<?php echo e($instructor->id); ?>">Delete</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

        </div>

        <div class="col-lg-3"></div>
    </div>
</div>
</body>
</html>


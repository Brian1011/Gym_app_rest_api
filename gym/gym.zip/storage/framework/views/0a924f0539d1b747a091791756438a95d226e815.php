<?php
/**
 * Created by PhpStorm.
 * User: Brian Mutinda
 * Date: 30/06/2018
 * Time: 04:37 PM
 */
?>

<html>
    <head>
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    </head>

    <body>
        <div class="container">

            <div class="row">
                <div class="col-lg-3"></div>
                <div class="col-lg-6">

                    <!--Check if there are errors-->
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <!--if errors exist print all of them-->
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                <!--Check for sucess message-->
                    <?php if(session()->has('message')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('message')); ?>

                        </div>
                    <?php endif; ?>
                    
                <!--Check for image name-->
                    <?php if(session()->has('path')): ?>
                        <div class="alert alert-sucess">
                            <?php echo e(session()->get('path')); ?>

                            <img src="/images/<?php echo e(Session::get('path')); ?>">
                        </div>
                    <?php endif; ?>

                    <h1>Register New Instructor</h1>
                    <form class="form" method="post" action="/instructor/save" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group">
                            <input type="file" name="select_file">
                        </div>

                        <div class="form-group">
                            <input type="text" placeholder="Full Name" name="full_name" class="form-control">
                        </div>

                        <div class="form-group">
                            <input type="text" placeholder="Contacts" name="contacts" class="form-control">
                        </div>

                        <div class="form-group">
                            <input type="text" placeholder="Email" name="email" class="form-control">
                        </div>

                        <div class="form-group">
                            <select name="gender" class="form-control">
                                <option vale="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Others">Others</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <select name="gym_id" class="form-control">
                                <?php $__currentLoopData = $gyms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gym): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($gym->id); ?>"><?php echo e($gym->gym_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <input type="submit" value="Submit" class="btn btn-primary">
                        </div>
                    </form>
                </div>
                <div class="col-lg-3"></div>
            </div>
        </div>
    </body>
</html>

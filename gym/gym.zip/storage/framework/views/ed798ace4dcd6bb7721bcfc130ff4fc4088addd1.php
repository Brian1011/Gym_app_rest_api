<?php
/**
 * Created by PhpStorm.
 * User: Brian Mutinda
 * Date: 30/06/2018
 * Time: 04:00 PM
 */
?>

<html>
<head>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>

<body>
<div class="container">
    <div class="row">
        <div class="col-lg-2"></div>

        <div class="col-lg-6">
            <h1>All Workout Sessions</h1>
            <!--Check for sucess message-->
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>

            <table class="table">
                <tr class="success">
                    <th>Workout Id</th>
                    <th>User Id</th>
                    <th>Date</th>
                    <th>Location</th>
                    <th>Workout Name</th>
                    <th>Number of reps</th>
                    <th>Delete Session</th>
                </tr>


                <?php $__currentLoopData = $workoutsession; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workoutsession): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($workoutsession->id); ?></td>
                        <td><?php echo e($workoutsession->user_id); ?></td>
                        <td><?php echo e($workoutsession->date); ?></td>
                        <td><?php echo e($workoutsession->location); ?></td>
                        <td><?php echo e($workoutsession->exercise_name); ?></td>
                        <td><?php echo e($workoutsession->number_of_reps); ?></td>
                        <td><a href="/workoutsession/<?php echo e($workoutsession->id); ?>">Erase</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </table>

        </div>

        <div class="col-lg-2"></div>
    </div>
</div>
</body>
</html>

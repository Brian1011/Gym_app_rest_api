<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WorkoutSessions extends Model
{
    //specify the table
    protected $table = "sessions_94006";
}

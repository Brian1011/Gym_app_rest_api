<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class usersController extends Controller
{
    //store a new user
    public function store(Request $request)
    {
        //validate the data
        $validatedData = Validator::make($request->all(), [
            'firstname'=>'required|string',
            'lastname'=>'required|string',
            'email'=>'required|string|email',
            'gender'=>'required|string',
            'password'=>'required|min:4',
            'age'=>'numeric',
            'weight'=>'numeric',
            'target_weight'=>'numeric',
            'preffered_location'=>'string',
        ]);

        //if validation fails give me an error
        if($validatedData->fails()){
            return response()->json($validatedData->errors());
        }

        $user = new User();
        $user->firstname = $request->input('firstname');
        $user->lastname = $request->input('lastname');
        $user->email=$request->input('email');
        $user->password = $request->input('password');
        $user->gender=$request->input('gender');
        $user->weight=$request->input('weight');
        $user->age=$request->input('age');
        $user->target_weight=$request->input('target_weight');
        $user->preffered_location=$request->input('preffered_location');
        $user->api_token = str_random(60);//generate random strings

        $user->save();

        return response()->json($user);

    }

    //show a specific user
    public function show($user_id)
    {
        //get the info for specific person
        $user = User::find($user_id);
        return response()->json($user);
    }

    //update user
    public function update(Request $request, $id)
    {

        try{
            //Check whether the user exists
            //$user = new User();
            $user = User::findOrFail($id);

            //get the data from the forms
            //validate the data
            $validatedData = Validator::make($request->all(), [
                'firstname'=>'required|string',
                'lastname'=>'required|string',
                'email'=>'required|string|email',
                'gender'=>'required|string',
                'password'=>'required|min:4',
                'age'=>'numeric',
                'weight'=>'numeric',
                'target_weight'=>'numeric',
                'preffered_location'=>'string',
            ]);

            //if validation fails give me an error
            if($validatedData->fails()){
                return response()->json($validatedData->errors());
            }

            $user->firstname = $request->input('firstname');
            $user->lastname = $request->input('lastname');
            $user->email=$request->input('email');
            $user->password = $request->input('password');
            $user->gender=$request->input('gender');
            $user->weight=$request->input('weight');
            $user->target_weight=$request->input('target_weight');
            $user->preffered_location=$request->input('preffered_location');
            //$user->api_token = str_random(60);//generate random strings

            $user->save();

            return response()->json($user);

        }catch (ModelNotFoundException $err){
            return response()->json($err);
        }

    }

    //erase a user
    public function destroy($id)
    {
        $user = User::find($id);
        $user->delete();

        return response('Account Erased');
    }

    /*WEBSITE VERSION*/
    public function webShowAll(){
        $user = User::all();
        return view('allusers',['users'=>$user]);
    }
}
